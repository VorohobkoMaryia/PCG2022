Файл .exe находится в Lab4/bin/Debug/Lab4.exe
